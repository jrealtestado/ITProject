@extends('layouts.assistantLayout')
@section('content')

<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	    Reports
	</h1>
	<ol class="breadcrumb">
        <li><a href="{{ url('/assistant') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="">Reports</li>
        <li class="active">Reports</li>
    </ol>
</section>
<section class="content">
	<div class="row">
        <div class="col-xs-12">
            <div class="box">
            <!-- /.box-header -->
                <div class="box-body">
                    <table id="example" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Service Rendered</th>
                                <th>Payment</th>
                                <th>Dentist</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($schedules) > 1)
                                @foreach($schedules as $schedule)
                                    @if($schedule->date == $today and $schedule->opStatus == 'Done')
                                        <tr>
                                            <td>{{$schedule->patient->name}}</td>
                                            <td>{{$schedule->service->servName}}</td>
                                            <td>{{$schedule->payment->amount}}</td>
                                            <td>{{$schedule->dentist->name}}</td>
                                        </tr>
                                    @endif
                                @endforeach
                            @else
                                <p>No Patient Found</p>
                            @endif                                
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</section>


@endsection