@extends('layouts.assistantLayout')
@section('content')

<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	    Low in Stock
	</h1>
	<ol class="breadcrumb">
        <li><a href="{{ url('/assistant') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="">Inventory</li>
        <li class="active">Reports</li>
    </ol>
</section>
<section class="content">
	<div class="row">
        <div class="col-xs-12">
            <div class="box">
            <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>


@endsection