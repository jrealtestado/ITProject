<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
       <?php echo e($patient->name); ?>

    </h1>
    <ol class="breadcrumb">
       <li><a href=<?php echo e(url('/assistant')); ?>><i class="fa fa-dashboard"></i> Home</a></li>
       <li><a href="<?php echo e(url('/assistant/patient')); ?>">Records</a></li>
       <li><a href="">History</a></li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Patient Teeth Operation History</h3>
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart18" >18</button>
                                        <div class="modal fade" id="modalCart18" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">18</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '18'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart17" >17</button>
                                        <div class="modal fade" id="modalCart17" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">17</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '17'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart16" >16</button>
                                        <div class="modal fade" id="modalCart16" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">16</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '16'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart15" >15</button>
                                        <div class="modal fade" id="modalCart15" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">15</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '15'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart14" >14</button>
                                        <div class="modal fade" id="modalCart14" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">14</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '14'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart13" >13</button>
                                        <div class="modal fade" id="modalCart13" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">13</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '13'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart12" >12</button>
                                        <div class="modal fade" id="modalCart12" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">12</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '12'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart11" >11</button>
                                        <div class="modal fade" id="modalCart11" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">11</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '11'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <center>                                                
                                            <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart21" >21</button>
                                            <div class="modal fade" id="modalCart21" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <!--Header-->
                                                        <div class="modal-header">
                                                            <h1 class="modal-title" id="myModalLabel">21</h1>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <!--Body-->
                                                        <div class="modal-body">
                                                            <?php  $limiter = 0  ?>
                                                            <?php  $pId = $patient->patID  ?>
                                                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($schedule->patID == $pId): ?>
                                                                    <?php if($schedule->teethID == '21'): ?>
                                                                        <?php  $limiter++  ?>
                                                                        <?php if($limiter < 5): ?>
                                                                        <h3><?php echo e($schedule->date); ?></h3>
                                                                        <hr>
                                                                        <table class="table table-hover">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <th style="width: 50%">Date</th>
                                                                                    <td><?php echo e($schedule->date); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Time From</th>
                                                                                    <td><?php echo e($schedule->timeFrom); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Time To</th>
                                                                                    <td><?php echo e($schedule->timeTo); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Operation Status</th>
                                                                                    <td><?php echo e($schedule->opStatus); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Dentist</th>
                                                                                    <td><?php echo e($schedule->dentist->name); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Services</th>
                                                                                    <td><?php echo e($schedule->service->servName); ?></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <?php else: ?>
                                                                            <?php  $limiter = 0  ?>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?> 
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <center>                                                
                                                <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart22" >22</button>
                                                <div class="modal fade" id="modalCart22" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <!--Header-->
                                                            <div class="modal-header">
                                                                <h1 class="modal-title" id="myModalLabel">22</h1>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">×</span>
                                                                </button>
                                                            </div>
                                                            <!--Body-->
                                                            <div class="modal-body">
                                                                <?php  $limiter = 0  ?>
                                                                <?php  $pId = $patient->patID  ?>
                                                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($schedule->patID == $pId): ?>
                                                                        <?php if($schedule->teethID == '22'): ?>
                                                                            <?php  $limiter++  ?>
                                                                            <?php if($limiter < 5): ?>
                                                                            <h3><?php echo e($schedule->date); ?></h3>
                                                                            <hr>
                                                                            <table class="table table-hover">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Date</th>
                                                                                        <td><?php echo e($schedule->date); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Time From</th>
                                                                                        <td><?php echo e($schedule->timeFrom); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Time To</th>
                                                                                        <td><?php echo e($schedule->timeTo); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Operation Status</th>
                                                                                        <td><?php echo e($schedule->opStatus); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Dentist</th>
                                                                                        <td><?php echo e($schedule->dentist->name); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Services</th>
                                                                                        <td><?php echo e($schedule->service->servName); ?></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                            <?php else: ?>
                                                                                <?php  $limiter = 0  ?>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?> 
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>

                                            <td>
                                                <center>                                                
                                                    <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart23" >23</button>
                                                    <div class="modal fade" id="modalCart23" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <!--Header-->
                                                                <div class="modal-header">
                                                                    <h1 class="modal-title" id="myModalLabel">23</h1>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <!--Body-->
                                                                <div class="modal-body">
                                                                    <?php  $limiter = 0  ?>
                                                                    <?php  $pId = $patient->patID  ?>
                                                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($schedule->patID == $pId): ?>
                                                                            <?php if($schedule->teethID == '23'): ?>
                                                                                <?php  $limiter++  ?>
                                                                                <?php if($limiter < 5): ?>
                                                                                <h3><?php echo e($schedule->date); ?></h3>
                                                                                <hr>
                                                                                <table class="table table-hover">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <th style="width: 50%">Date</th>
                                                                                            <td><?php echo e($schedule->date); ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <th style="width: 50%">Time From</th>
                                                                                            <td><?php echo e($schedule->timeFrom); ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <th style="width: 50%">Time To</th>
                                                                                            <td><?php echo e($schedule->timeTo); ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <th style="width: 50%">Operation Status</th>
                                                                                            <td><?php echo e($schedule->opStatus); ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <th style="width: 50%">Dentist</th>
                                                                                            <td><?php echo e($schedule->dentist->name); ?></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <th style="width: 50%">Services</th>
                                                                                            <td><?php echo e($schedule->service->servName); ?></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                                <?php else: ?>
                                                                                    <?php  $limiter = 0  ?>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?> 
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>

                                <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart24" >24</button>
                                        <div class="modal fade" id="modalCart24" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">24</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '24'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <center>                                                
                                            <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart25" >25</button>
                                            <div class="modal fade" id="modalCart25" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <!--Header-->
                                                        <div class="modal-header">
                                                            <h1 class="modal-title" id="myModalLabel">25</h1>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <!--Body-->
                                                        <div class="modal-body">
                                                            <?php  $limiter = 0  ?>
                                                            <?php  $pId = $patient->patID  ?>
                                                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($schedule->patID == $pId): ?>
                                                                    <?php if($schedule->teethID == '25'): ?>
                                                                        <?php  $limiter++  ?>
                                                                        <?php if($limiter < 5): ?>
                                                                        <h3><?php echo e($schedule->date); ?></h3>
                                                                        <hr>
                                                                        <table class="table table-hover">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <th style="width: 50%">Date</th>
                                                                                    <td><?php echo e($schedule->date); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Time From</th>
                                                                                    <td><?php echo e($schedule->timeFrom); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Time To</th>
                                                                                    <td><?php echo e($schedule->timeTo); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Operation Status</th>
                                                                                    <td><?php echo e($schedule->opStatus); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Dentist</th>
                                                                                    <td><?php echo e($schedule->dentist->name); ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="width: 50%">Services</th>
                                                                                    <td><?php echo e($schedule->service->servName); ?></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <?php else: ?>
                                                                            <?php  $limiter = 0  ?>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?> 
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart26" >26</button>
                                        <div class="modal fade" id="modalCart26" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">26</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '26'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart27" >27</button>
                                        <div class="modal fade" id="modalCart27" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">27</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '27'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart28" >28</button>
                                        <div class="modal fade" id="modalCart28" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">28</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '28'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart38" >38</button>
                                        <div class="modal fade" id="modalCart38" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">38</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '38'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart37" >37</button>
                                        <div class="modal fade" id="modalCart37" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">37</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '37'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart36" >36</button>
                                        <div class="modal fade" id="modalCart36" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">36</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '36'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart35" >35</button>
                                        <div class="modal fade" id="modalCart35" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">35</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '35'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart34" >34</button>
                                        <div class="modal fade" id="modalCart34" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">34</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '34'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart33" >33</button>
                                        <div class="modal fade" id="modalCart33" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">33</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '33'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart32" >32</button>
                                        <div class="modal fade" id="modalCart32" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">32</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '32'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart31" >31</button>
                                        <div class="modal fade" id="modalCart31" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">31</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '31'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart41" >41</button>
                                        <div class="modal fade" id="modalCart41" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">41</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '41'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart42" >42</button>
                                        <div class="modal fade" id="modalCart42" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">42</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '42'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart43" >43</button>
                                        <div class="modal fade" id="modalCart43" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">43</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '43'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart44" >44</button>
                                        <div class="modal fade" id="modalCart44" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">44</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '44'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart45" >45</button>
                                        <div class="modal fade" id="modalCart45" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">45</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '45'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart46" >46</button>
                                        <div class="modal fade" id="modalCart46" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">46</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '46'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart47" >47</button>
                                        <div class="modal fade" id="modalCart47" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">47</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '47'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <center>                                                
                                        <button class="btn btn-info" style="margin: 2px" data-toggle="modal" data-target="#modalCart48" >48</button>
                                        <div class="modal fade" id="modalCart48" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <!--Header-->
                                                    <div class="modal-header">
                                                        <h1 class="modal-title" id="myModalLabel">48</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <!--Body-->
                                                    <div class="modal-body">
                                                        <?php  $limiter = 0  ?>
                                                        <?php  $pId = $patient->patID  ?>
                                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($schedule->patID == $pId): ?>
                                                                <?php if($schedule->teethID == '48'): ?>
                                                                    <?php  $limiter++  ?>
                                                                    <?php if($limiter < 5): ?>
                                                                    <h3><?php echo e($schedule->date); ?></h3>
                                                                    <hr>
                                                                    <table class="table table-hover">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th style="width: 50%">Date</th>
                                                                                <td><?php echo e($schedule->date); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time From</th>
                                                                                <td><?php echo e($schedule->timeFrom); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Time To</th>
                                                                                <td><?php echo e($schedule->timeTo); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Operation Status</th>
                                                                                <td><?php echo e($schedule->opStatus); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Dentist</th>
                                                                                <td><?php echo e($schedule->dentist->name); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th style="width: 50%">Services</th>
                                                                                <td><?php echo e($schedule->service->servName); ?></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <?php else: ?>
                                                                        <?php  $limiter = 0  ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?> 
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <table class="table table-bordered">
                        <tbody>
                            <tr>
                            <td style="width: 33%">
                                <center>                                                
                                    <button class="btn btn-info" style="width: 100%" data-toggle="modal" data-target="#modalCartUpper" >Upper Teeth</button>
                                    <div class="modal fade" id="modalCartUpper" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <!--Header-->
                                                <div class="modal-header">
                                                    <h1 class="modal-title" id="myModalLabel">Upper Teeth</h1>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <!--Body-->
                                                <div class="modal-body">
                                                    <?php  $limiter = 0  ?>
                                                    <?php  $pId = $patient->patID  ?>
                                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($schedule->patID == $pId): ?>
                                                            <?php if($schedule->teethID == '2'): ?>
                                                                <?php  $limiter++  ?>
                                                                <?php if($limiter < 5): ?>
                                                                <h3><?php echo e($schedule->date); ?></h3>
                                                                <hr>
                                                                <table class="table table-hover">
                                                                    <tbody>
                                                                        <tr>
                                                                            <th style="width: 50%">Date</th>
                                                                            <td><?php echo e($schedule->date); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Time From</th>
                                                                            <td><?php echo e($schedule->timeFrom); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Time To</th>
                                                                            <td><?php echo e($schedule->timeTo); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Operation Status</th>
                                                                            <td><?php echo e($schedule->opStatus); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Dentist</th>
                                                                            <td><?php echo e($schedule->dentist->name); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Services</th>
                                                                            <td><?php echo e($schedule->service->servName); ?></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <?php else: ?>
                                                                    <?php  $limiter = 0  ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td style="width: 33%">
                                <center>                                                
                                    <button class="btn btn-info" style="width: 100%" data-toggle="modal" data-target="#modalCartAll" >All</button>
                                    <div class="modal fade" id="modalCartAll" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <!--Header-->
                                                <div class="modal-header">
                                                    <h1 class="modal-title" id="myModalLabel">All</h1>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <!--Body-->
                                                <div class="modal-body">
                                                    <?php  $limiter = 0  ?>
                                                    <?php  $pId = $patient->patID  ?>
                                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($schedule->patID == $pId): ?>
                                                            <?php if($schedule->teethID == '1'): ?>
                                                                <?php  $limiter++  ?>
                                                                <?php if($limiter < 5): ?>
                                                                <h3><?php echo e($schedule->date); ?></h3>
                                                                <hr>
                                                                <table class="table table-hover">
                                                                    <tbody>
                                                                        <tr>
                                                                            <th style="width: 50%">Date</th>
                                                                            <td><?php echo e($schedule->date); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Time From</th>
                                                                            <td><?php echo e($schedule->timeFrom); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Time To</th>
                                                                            <td><?php echo e($schedule->timeTo); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Operation Status</th>
                                                                            <td><?php echo e($schedule->opStatus); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Dentist</th>
                                                                            <td><?php echo e($schedule->dentist->name); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Services</th>
                                                                            <td><?php echo e($schedule->service->servName); ?></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <?php else: ?>
                                                                    <?php  $limiter = 0  ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td style="width: 33%">
                                <center>                                                
                                    <button class="btn btn-info" style="width: 100%" data-toggle="modal" data-target="#modalCartLower" >Lower Teeth</button>
                                    <div class="modal fade" id="modalCartLower" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <!--Header-->
                                                <div class="modal-header">
                                                    <h1 class="modal-title" id="myModalLabel">Lower Teeth</h1>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <!--Body-->
                                                <div class="modal-body">
                                                    <?php  $limiter = 0  ?>
                                                    <?php  $pId = $patient->patID  ?>
                                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($schedule->patID == $pId): ?>
                                                            <?php if($schedule->teethID == '3'): ?>
                                                                <?php  $limiter++  ?>
                                                                <?php if($limiter < 5): ?>
                                                                <h3><?php echo e($schedule->date); ?></h3>
                                                                <hr>
                                                                <table class="table table-hover">
                                                                    <tbody>
                                                                        <tr>
                                                                            <th style="width: 50%">Date</th>
                                                                            <td><?php echo e($schedule->date); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Time From</th>
                                                                            <td><?php echo e($schedule->timeFrom); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Time To</th>
                                                                            <td><?php echo e($schedule->timeTo); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Operation Status</th>
                                                                            <td><?php echo e($schedule->opStatus); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Dentist</th>
                                                                            <td><?php echo e($schedule->dentist->name); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th style="width: 50%">Services</th>
                                                                            <td><?php echo e($schedule->service->servName); ?></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <?php else: ?>
                                                                    <?php  $limiter = 0  ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        </tbody>
                        </table>


                    </div>
                </div>
            </div>
        </div>
    </div>
</section>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>