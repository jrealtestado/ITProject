<?php $__env->startSection('content'); ?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Patient Records
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Records</li>
            </ol>
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example1" class="table table-bordered table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Contact No.</th>
                                        <th>Age</th>
                                        <th>Sex</th>
                                        <th>Patient Status</th>
                                        <th style ="width: 25%">Options</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($patients) > 0): ?>
                                    <?php $counter = 0 ?>
                                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $counter++ ?>
                                            <tr>
                                                <td><?php echo e($patient->name); ?></td>
                                                <td><?php echo e($patient->address); ?></td>
                                                <td><?php echo e($patient->patientTelNo); ?></td>
                                                <td><?php echo e($patient->age); ?></td>
                                                <td><?php echo e($patient->sex); ?></td>
                                                <td><?php echo e($patient->patStatus); ?></td>
                                                <td>
                                                    <div class="modal fade" id="modalCart<?php echo e($counter); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <!--Header-->
                                                                <div class="modal-header">
                                                                    <h1 class="modal-title" id="myModalLabel"><?php echo e($patient->name); ?></h1>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <!--Body-->
                                                                <div class="modal-body">
                                                                    <?php  $limiter = 0  ?>
                                                                    <?php  $pId = $patient->patID  ?>
                                                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($schedule->patID == $pId): ?>
                                                                            <?php  $limiter++  ?>
                                                                            <?php if($limiter < 5): ?>
                                                                            <h3><?php echo e($schedule->date); ?></h3>
                                                                            <hr>
                                                                            <table class="table table-hover">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Date</th>
                                                                                        <td><?php echo e($schedule->date); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Time From</th>
                                                                                        <td><?php echo e($schedule->timeFrom); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Time To</th>
                                                                                        <td><?php echo e($schedule->timeTo); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Operation Status</th>
                                                                                        <td><?php echo e($schedule->opStatus); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Dentist</th>
                                                                                        <td><?php echo e($schedule->dentist->name); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th style="width: 50%">Services</th>
                                                                                        <td><?php echo e($schedule->service->servName); ?></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th>Balance</th>
                                                                                        <td><?php echo e($patient->balance); ?></td>
                                                                                        <th></th>
                                                                                        <td><button class="btn btn-success">Pay</button></td>
                                                                                    </tr>    
                                                                                </tbody>
                                                                            </table>
                                                                            <?php else: ?>
                                                                                <?php  $limiter = 0  ?>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                                <!--Footer-->
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                                                                    <button class="btn btn-primary">Checkout</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <button class="btn btn-info pull-right" style="margin: 2px" data-toggle="modal" data-target="#modalCart<?php echo e($counter); ?>" ><i class="fa fa-pencil" ></i>History</button>
                                                    <a href="<?php echo e(url('/admin/patient' . '/' . $patient->patID)); ?>" class="btn btn-primary pull-right" style="margin: 2px"><i class="fa fa-folder"></i> Profile</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <p>No patients found</p>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
    <!-- /.content -->
  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>