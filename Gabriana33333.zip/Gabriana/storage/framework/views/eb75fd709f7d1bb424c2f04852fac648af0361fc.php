<center>
<?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
        <div class="alert alert-success" style = "margin: 0px 0px 0px 230px">
            <?php echo e(session('success')); ?>

        </div> 
<?php endif; ?>

<?php if(session('error')): ?>
        <div class="alert alert-danger" style = "margin: 0px 0px 0px 230px">
            <?php echo e(session('error')); ?>

        </div> 
<?php endif; ?>
</center>